/* Copyright (C) 2015 Texas Instruments Incorporated - http://www.ti.com/  ALL RIGHTS RESERVED  */

#ifndef HDC1080_CMD_H_
#define HDC1080_CMD_H_

#define HDC1080_I2C_ADDRESS			0x40
// calibration raw points
#define HDC1080_CALPTS_TEMP 		0
#define HDC1080_CALPTS_HUMIDITY 	2
#define HDC1080_CALPTS_SIZE       	4

// calibration formula constants; y = mx + b; m is SCALE, b is OFFSET
#define HDC1080_CALCONST_OFFSET    0
#define HDC1080_CALCONST_SCALE     1
#define HDC1080_CALCONST_TEMP 		0
#define HDC1080_CALCONST_HUMIDITY 	2
#define HDC1080_CALCONST_SET_SIZE  2
#define HDC1080_CALCONST_SIZE		4
#define HDC1080_CALCONST_SET_NUM   (HDC1080_CALCONST_SIZE / HDC1080_CALCONST_SET_SIZE)

// HDC COMMANDS
#define HDC1080_CMD_TEMP        0x00
#define HDC1080_CMD_HUMIDITY    0x01
#define HDC1080_CMD_CONFIG 		0x02
#define HDC1080_CMD_SERIALID2 	0xFB
#define HDC1080_CMD_SERIALID1 	0xFC
#define HDC1080_CMD_SERIALID0 	0xFD
#define HDC1080_CMD_MANUFACTID	0xFE
#define HDC1080_CMD_DEVID	    0xFF


//definition of MCP9808 sensors. all registers are 16 bit
#define MCP9808_I2C_ADDRESS		0x18

#define MCP9808_CMD_CONFIG		0x01
#define MCP9808_CMD_TUPPER		0x02
#define MCP9808_CMD_TLOWER		0x03
#define MCP9808_CMD_TCRIT		0x04
#define MCP9808_CMD_TABIENT		0x05
#define MCP9808_CMD_MID			0x06
#define MCP9808_CMD_DEVID		0x07
#define MCP9808_CMD_RESOLUTION	0x08




/** @name - DRDYN Pin Definition - TODO update the name and pins*/
#if 0
//@{
#define EVM_DRDYN_DIR 	P1DIR	/**< Define Data Ready direction register */
#define EVM_DRDYN_IN	P1IN    /**< Define Data Ready input status */
#define EVM_DRDYN_SEL 	P1SEL	/**< Define Data Ready selection register */
#define EVM_DRDYN_BIT 	BIT0	/**< Define Data Ready bit register */
#define EVM_DRDYN_REN	P1REN
#define EVM_DRDYN_OUT   P1OUT
#define EVM_DRDYN_IES   P1IES

#endif
//@}


#endif /* HDC1080_CMD_H_ */

/** @} */
