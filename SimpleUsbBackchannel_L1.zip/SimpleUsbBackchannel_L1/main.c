/* --COPYRIGHT--,BSD
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//   MSP430F5529LP:  simpleUsbBackchannel example
//
//   Description: 	Demonstrates simple sending over USB, as well as the F5529's
//                  backchannel UART.
//
//   Texas Instruments Inc.
//   August 2013
//******************************************************************************

// Basic MSP430 and driverLib #includes
#include "msp430.h"
#include "driverlib/MSP430F5xx_6xx/wdt_a.h"
#include "driverlib/MSP430F5xx_6xx/ucs.h"
#include "driverlib/MSP430F5xx_6xx/pmm.h"
#include "driverlib/MSP430F5xx_6xx/sfr.h"

// USB API #includes
#include "USB_config/descriptors.h"
#include "USB_API/USB_Common/device.h"
#include "USB_API/USB_Common/types.h"
#include "USB_API/USB_Common/usb.h"
#include "USB_API/USB_CDC_API/UsbCdc.h"

#include "USB_app/usbConstructs.h"
#include "driverlib/i2c.h"
#include "driverlib/sensor_cmd.h"
#include "driverlib/scheduler.h"
// Application #includes
#include "BCUart.h"           // Include the backchannel UART "library"
#include "hal.h"              // Modify hal.h to select your hardware
#include "host_packet.h"
#include "host_interface.h"

extern volatile uint16_t timer_ticks;
/* You have a choice between implementing this as a CDC USB device, or a HID-
 * Datapipe device.  With CDC, the USB device presents a COM port on the host;
 * you interact with it with a terminal application, like Hyperterminal or
 * Docklight.  With HID-Datapipe, you interact with it using the Java HID Demo
 * App available within the MSP430 USB Developers Package.
 *
 * By default, this app uses CDC.  The HID calls are included, but commented
 * out.
 *
 * See the F5529 LaunchPad User's Guide for simple instructions to convert
 * this demo to HID-Datapipe.  For deeper information on CDC and HID-Datapipe,
 * see the USB API Programmer's Guide in the USB Developers Package.
 */


// Global variables
WORD rxByteCount;                        // Momentarily stores the number of bytes received
BYTE buf_bcuartToUsb[BC_RXBUF_SIZE];     // Same size as the UART's rcv buffer
BYTE buf_usbToBcuart[128];               // This can be any size

// see usbEventHandling.c
volatile uint8_t bCDCDataReceived_event = FALSE;           //Flag set by event handler to indicate some data has been received into USB buffer without open rcv operation


void printMenu();
void getMeasurementData();
void read_temp_through_i2c(host_cmd_packet_t *);
void USBCommunicationTask(void);
void initHDC1080();

void main(void)
{
	WDTCTL = WDTPW + WDTHOLD;		// Halt the dog
	int i,j, index;

    // MSP430 USB requires a Vcore setting of at least 2.  2 is high enough
	// for 8MHz MCLK, below.
    PMM_setVCore(PMM_CORE_LEVEL_2);

    initPorts();           // Config all the GPIOS for low-power (output low)
    i2c_setup();		   // init I2C
    initClocks(8000000);   // Config clocks. MCLK=SMCLK=FLL=8MHz; ACLK=REFO=32kHz
    bcUartInit();          // Init the back-channel UART
    USB_setup(TRUE,TRUE);  // Init USB; if a USB host (PC) is present, connect
    __enable_interrupt();  // Enable interrupts globally

    initHostInterface();

    initHDC1080();

    while(1)
    {
    	/*
       // Look for rcv'ed bytes on the backchannel UART. If any, send over USB.
       rxByteCount = bcUartReceiveBytesInBuffer(buf_bcuartToUsb);
       if(rxByteCount)
       {
           cdcSendDataInBackground(buf_bcuartToUsb, rxByteCount, CDC0_INTFNUM, 1000);
           //hidSendDataInBackground(buf_bcuartToUsb, rxByteCount, HID0_INTFNUM, 1000);
       }

       // Look for received bytes over USB. If any, send over backchannel UART.
       rxByteCount = cdcReceiveDataInBuffer(buf_usbToBcuart, sizeof(buf_usbToBcuart), CDC0_INTFNUM);
       //rxByteCount = hidReceiveDataInBuffer(buf_usbToBcuart, sizeof(buf_usbToBcuart), HID0_INTFNUM);
       if(rxByteCount)
       {
           bcUartSend(buf_usbToBcuart, rxByteCount);
       }
       */

    	//rxByteCount = cdcReceiveDataInBuffer(buf_usbToBcuart, sizeof(buf_usbToBcuart), CDC0_INTFNUM);
	   //rxByteCount = hidReceiveDataInBuffer(buf_usbToBcuart, sizeof(buf_usbToBcuart), HID0_INTFNUM);
	   //if(rxByteCount)
	   {
		   //if (buf_usbToBcuart[0]=='p')
		   {
			   USBCommunicationTask();
			//   printMenu();
		   }
		   //bcUartSend(buf_usbToBcuart, rxByteCount);
		 //  cdcSendDataInBackground(buf_bcuartToUsb, rxByteCount, CDC0_INTFNUM, 1000);
	   }

    }
}

void read_temp_through_i2c(host_cmd_packet_t *responsePkt)
{
#if 0
	uint8_t i, j;
	uint32_t data;


	// initiate conversion
	if (!i2c_writeByte(responsePkt->fields.data[0], HDC1080_CMD_TEMP)) {
		sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT); //TODO Error handling
	}
	else
	{
		//TODO, implement a timeout
		data = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};
		//while (timer_ticks != data) {};

		// read data
		if (!i2c_readBytes(responsePkt->fields.data[0], &responsePkt->fields.data[1], 2)) {
			sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT); //TODO Error handling
		}
		else {
			data = (responsePkt->fields.data[1] << 8) | responsePkt->fields.data[2];
			i = (responsePkt->fields.hdr.device_num-1)*HDC1080_CALCONST_SIZE+HDC1080_CALCONST_TEMP;
			data = applyCalConst(data, i); // apply calibration params only applied to HDC1808

			responsePkt->fields.data[1] = (data >> 8) & 0xFF;
			responsePkt->fields.data[2] = data & 0xFF;

			responsePkt->fields.hdr.length = 3;
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
		}

	}
#endif

	return;

}

void getMeasurementData()
{
	static host_cmd_packet_t       responsePkt;

	read_temp_through_i2c(&responsePkt);
}

void USBCommunicationTask(void)
{
  static uint16_t bytesSent, bytesReceived;
//  uint16_t count;
//  uint8_t send_error=0, receive_error=0; //send_response;//, i;
  static uint8_t error=0;
  static uint8_t status;

        switch (USB_connectionState())
        {
            case ST_ENUM_ACTIVE:
            	/*
            	if (!usb_led_flag) {
            		//evm_LED_Set(GREEN); // green on only
            		usb_led_flag = 1;
            	}
            	*/
            	status = USBCDC_intfStatus(CDC0_INTFNUM,&bytesSent, &bytesReceived);
                if (status & kUSBCDC_waitingForSend) {
                	error = 1;
                }
                // Exit LPM because of a data-receive event, and fetch the received data
                if(bCDCDataReceived_event || (status & kUSBCDC_dataWaiting))
                {
                    bCDCDataReceived_event = FALSE;
                    processCmdPacket ();
                }
                else {
                	executeTasks();
                }
                break;

            case ST_USB_DISCONNECTED: case ST_USB_CONNECTED_NO_ENUM:
            case ST_ENUM_IN_PROGRESS: case ST_NOENUM_SUSPENDED: case ST_ERROR:
            	/*
            	if (usb_led_flag) {
            		//evm_LED_Set(RED); // red on only
            		usb_led_flag = 0;
            	}
            	*/
            	break;
            default:
            	break;
        }                                                                            //end of switch-case sentence
        if(error)
        {
        	error = 0;
        	_nop();
          //TO DO: User can place code here to handle error
        }
}

void initHDC1080()
{
	uint16_t config;
	// software reset
	smbus_writeWord(HDC1080_I2C_ADDRESS,HDC1080_CMD_CONFIG,0x8000);

	config = 0x0;  //may need to change this value to measure both
				   //temp & humidity
	// acq. temp and humidity independently, heater disabled, 14-bit res
	smbus_writeWord(EVM_DEFAULT_I2CADDR,HDC1080_CMD_CONFIG,config);
}


