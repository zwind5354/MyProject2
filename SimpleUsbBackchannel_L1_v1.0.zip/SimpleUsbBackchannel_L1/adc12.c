/*  Copyright 2011-2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user who
  downloaded the software, his/her employer (which must be your employer) and
  Texas Instruments Incorporated (the "License"). You may not use this Software
  unless you agree to abide by the terms of the License. The License limits your
  use, and you acknowledge, that the Software may not be modified, copied or
  distributed unless embedded on a Texas Instruments microcontroller which is 
  integrated into your product. Other than for the foregoing purpose, you may 
  not use, reproduce, copy, prepare derivative works of, modify, distribute, 
  perform, display or sell this Software and/or its documentation for any 
  purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL TEXAS
  INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL
  EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT
  LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL
  DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS,
  TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT
  LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/
//******************************************************************************
// CC430/LM57 Interface Code                 | 
//
// Vishy N Viswanathan
// Texas Instruments Inc.
// Feb 2013
// Built IAR Embedded Workbench Version:  5.5x
//******************************************************************************
// Change Log:
//******************************************************************************
// Version:  1.00
// Comments: Initial Release Version
//******************************************************************************

//******************************************************************************
#include <stdint.h>
#include "msp430.h"
#include "adc12.h"

#define POW2L(x)   (1L<<x)
//******************************************************************************
extern uint8_t overflow_count;
extern uint8_t TIMER_DONE_FLAG;
extern uint16_t calREF_factor, calADC10_gain;
extern int16_t calADC10_offset;
float ADC12_Ratio;
extern uint8_t bufferX[], bufferY[];
extern uint8_t *mbuf, *ubuf;
extern volatile uint8_t LMT70_ADCReady;
extern uint16_t xy_buf_length;
extern volatile uint16_t LMT70_ADC_Value;
//******************************************************************************
void adc12_init(uint8_t ckd)
{

  // Select ADC12 Input A6
  TI_LMT70_ADC12_INP_PxSEL |= TI_LMT70_ADC12_INP_PIN;
  // Select VeREF+ on P5.0
  TI_LMT70_GPIO_INTVREF_PxSEL |= TI_LMT70_GPIO_INTVREF_PIN;
  TI_LMT70_GPIO_INTVREF_PxDIR |= TI_LMT70_GPIO_INTVREF_PIN;
  
  REFCTL0 &= ~REFMSTR;                                                         // Reset REFMSTR to hand over control to 
                                                                               // ADC12_A ref control registers  
  ADC12CTL0 = ADC12ON+ADC12SHT0_8+ADC12MSC;                                    // Turn on ADC12, set sampling time
                                                                               // set multiple sample conversion
  ADC12CTL0 |= ADC12REFON;                                                     // Turn on Ref Gen 
  ADC12CTL0 &= ~ADC12REF2_5V;                                                  // 1.5V reference
  ADC12MCTL0 = ADC12SREF_1;                                                    // Vr+ = Vref+ and Vr- = AVSS
  ADC12CTL1 = ADC12SHP+ADC12CONSEQ_0;                                          // Use sampling timer, set mode
  // Divide ADC clock (5MHz MODOSC) by 4
  ADC12CTL1 |= (ckd*0x20u);
  ADC12CTL2 |= ADC12REFOUT;                                                    // Bring the ref out  
  ADC12IE = ADC12IE0;                                                          // Enable ADC12IFG.0
  __delay_cycles(500);                                                         // delay to allow Ref to settle
  ADC12CTL0 |= ADC12ENC;                                                       // Enable conversions
//  ADC12CTL0 |= ADC12SC;                                                        // Start conversion
  
  // with 1.5V reference
  ADC12_Ratio = 1.5 / 4096;

  LMT70_ADCReady = 0;
 
}
//******************************************************************************
void read_adc12_result(uint8_t adc_ch)
{

  __delay_cycles(5000);
  // disable ADC
  ADC12CTL0 &= ~ADC12ENC;
  // clear any previous channel selection
  ADC12MCTL0 &= ~ADC12INCH_15;        
  // select new channel for conversion
  ADC12MCTL0 |= adc_ch;
  // enable ADC and start conversion
  ADC12CTL0 |= ADC12ENC + ADC12SC;                                             // Sampling and conversion start
//  __bis_SR_register(LPM0_bits + GIE);                                          // Enter LPM0, ADC12_ISR will force exit

}

//******************************************************************************
void read_adc12_calibration(uint16_t *ref, uint16_t *gain, int16_t *offset, uint8_t vrf)
{

  uint8_t id_byte1, id_byte2;
  
  
  id_byte1 = (*(uint8_t *)0x1A04);
  id_byte2 = (*(uint8_t *)0x1A05);
              
  if ((id_byte1 != 0x55) || (id_byte2 != 0x29))
    // error flash LED
    while (1)
    {
      __delay_cycles(260000);
    }
  
  switch (vrf)
  {
    case VREF_15:
      *ref = (*(uint16_t *)0x01A28);
      break;
    case VREF_20:
      *ref = (*(uint16_t *)0x01A2A);
      break;
    case VREF_25:
      *ref = (*(uint16_t *)0x01A2C);
      break;
    default:
      *ref = (*(uint16_t *)0x01A28);
      break;
  }
  *gain = (*(uint16_t *)0x01A16);
  *offset = (*(int16_t *)0x01A18);
}
//******************************************************************************
float calibrateADCReading(uint16_t adc_raw)
{
   float result64 = 0;
   float result16;
   
   result64 = adc_raw;

   // Compensate for the reference voltage
   result64 *= calREF_factor;

   // Compensate for the ADC gain
   result64 *= calADC10_gain;

   // Normalize the previous two compensations and check for overflow
   // result16 = (uint16_t)(result64 >> 30);
   result16 =  result64 / POW2L(30);

   // Factor in the ADC offset (Offset is a 16-bit signed value) and check for
   // overflow/underflow
   result16 += calADC10_offset;
   if (result16 < 0)  // result is negative, we had underflow
   {
      result16 = 0.0;
   }
   else if (result16 > ADC12_MAX_SAMPLE) // overflow happened
   {
      result16 = (float) ADC12_MAX_SAMPLE;
   }

   return(result16);
}
//******************************************************************************
// ADC12 interrupt service routine
#pragma vector=ADC12_VECTOR
__interrupt void ADC12_ISR(void)
{
  //static uint16_t index = 0;
  //uint16_t rdata;
  
  switch(__even_in_range(ADC12IV,34))
  {
  case  0: break;                           // Vector  0:  No interrupt
  case  2: break;                           // Vector  2:  ADC overflow
  case  4: break;                           // Vector  4:  ADC timing overflow
  case  6: 
          LMT70_ADC_Value = ADC12MEM0;
          LMT70_ADCReady = 1;
           /*
           mbuf[index++] = rdata;
           mbuf[index++] = rdata >> 8;
           if (index == xy_buf_length)
           {
             LMT70_XYBufferReady = 1;
             ubuf = mbuf;
             if (mbuf == bufferX)
               mbuf = bufferY;
             else
               mbuf = bufferX;             
             index = 0;
//             __bic_SR_register_on_exit(LPM0_bits);                                             
           }*/

           break;                           // Vector  6:  ADC12IFG0
  case  8: break;                           // Vector  8:  ADC12IFG1
  case 10: break;                           // Vector 10:  ADC12IFG2
  case 12: 
           break;                           // Clear CPUOFF bit from 0(SR)
  case 14: break;                           // Vector 14:  ADC12IFG4
  case 16: break;                           // Vector 16:  ADC12IFG5
  case 18: break;                           // Vector 18:  ADC12IFG6
  case 20: break;                           // Vector 20:  ADC12IFG7
  case 22: break;                           // Vector 22:  ADC12IFG8
  case 24: break;                           // Vector 24:  ADC12IFG9
  case 26: break;                           // Vector 26:  ADC12IFG10
  case 28: break;                           // Vector 28:  ADC12IFG11
  case 30: break;                           // Vector 30:  ADC12IFG12
  case 32: break;                           // Vector 32:  ADC12IFG13
  case 34: break;                           // Vector 34:  ADC12IFG14           
  default: break; 
  } 
}
//******************************************************************************
