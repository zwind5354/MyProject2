/* Copyright (C) 2015 Texas Instruments Incorporated - http://www.ti.com/  ALL RIGHTS RESERVED  */

//#include <intrinsics.h>
#include <stdint.h>
#include <string.h>
//#include <cstring>
#include <stdio.h>

#include "driverlib/i2c.h"
#include "driverlib/crc8.h"

//#include "HDC1000_cmd.h"
//#include "HDC1000_evm.h"
#include "host_interface.h"
#include "host_menu.h"
#include "driverlib/scheduler.h"
#include "adc12.h"

//#include "flash.h"
//#include "HAL_PMM.h"

#include "USB_API/USB_Common/device.h"
#include "USB_API/USB_Common/types.h"               //Basic Type declarations
#include "USB_API/USB_Common/usb.h"                 //USB-specific functions
#include "driverlib/sensor_cmd.h"
#include "USB_API/USB_CDC_API/UsbCdc.h"
#include "USB_app/usbConstructs.h"
#include "USB_config/descriptors.h"

#define HOST_INTERFACE_MAX_STREAM_TASKS 5

// calibration raw points
#define HOST_CALPTS_TEMP 		0
#define HOST_CALPTS_HUMIDITY 	2
#define HOST_CALPTS_SIZE       	4

// calibration formula constants; y = mx + b; m is SCALE, b is OFFSET
#define HOST_CALCONST_OFFSET    0
#define HOST_CALCONST_SCALE     1
#define HOST_CALCONST_TEMP 		0
#define HOST_CALCONST_HUMIDITY 	2
#define HOST_CALCONST_SET_SIZE  2
#define HOST_CALCONST_SIZE		4
#define HOST_CALCONST_SET_NUM   (HOST_CALCONST_SIZE / HOST_CALCONST_SET_SIZE)

#define HOST_STREAM_TICKS_DEF   100000UL // 1sec
#define HOST_STREAM_TICKS_MIN   1000 // 10ms
#define HOST_STREAM_TICKS_MAX   3000000UL // 30 sec
#define HOST_STREAM_TICKS_INC   1000 // 10ms

#define HOST_DRDY_TIMEOUT_TICKS 1500 // 15ms

#define INFOC_START   (0x1880)


/** @name - GREEN LED Pin Definition - */
//@{ P7.6
#define TP1_LEDOUT            P7OUT	/**< Define green led pin output register */
#define TP1_LEDDIR            P7DIR	/**< Define green led pin direction register */
#define TP1_LEDBIT            BIT6	/**< Define green led pin bit register */
//@}
/** @name - RED LED Pin Definition - */
//@{
#define TP2_LEDOUT            P7OUT	/**< Define red led pin output register */
#define TP2_LEDDIR            P7DIR	/**< Define red led pin direction register */
#define TP2_LEDBIT            BIT5	/**< Define red led pin bit register */
//@}

/** @name - Test Point 3 Pin Definition - */
//@{ P1.7
#define TP3_OUT             P1OUT /**< Define green led pin output register */
#define TP3_DIR             P1DIR /**< Define green led pin direction register */
#define TP3_BIT             BIT7  /**< Define green led pin bit register */
//@}
/** @name - Test Point 4 Pin Definition - */
//@{
#define TP4_OUT             P1OUT /**< Define red led pin output register */
#define TP4_DIR             P1DIR /**< Define red led pin direction register */
#define TP4_BIT             BIT0  /**< Define red led pin bit register */
//@}

/** @name - LED Function Macros - */
//@{
#define TP1_LED_ON()	      (TP1_LEDOUT |= TP1_LEDBIT)  /**< Green LED ON */
#define TP1_LED_OFF()         (TP1_LEDOUT &= ~TP1_LEDBIT) /**< Green LED OFF */
#define TP2_LED_ON()	      (TP2_LEDOUT |= TP2_LEDBIT)  /**< Red LED ON */
#define TP2_LED_OFF()         (TP2_LEDOUT &= ~TP2_LEDBIT) /**< Red LED OFF */

#define TP3_ON()            (TP3_OUT |= TP3_BIT)  /**< TP3 ON */
#define TP3_OFF()           (TP3_OUT &= ~TP3_BIT) /**< TP3 OFF */
#define TP4_ON()            (TP4_OUT |= TP4_BIT)  /**< TP4 ON */
#define TP4_OFF()           (TP4_OUT &= ~TP4_BIT) /**< TP4 OFF */

#define NUM_ADC_SAMPLES_IN_BITS        (8)
#define NUM_ADC_SAMPLES             (1<<NUM_ADC_SAMPLES_IN_BITS)
static uint32_t gAdc_Acccumlator = 0;
//@}

// flash memory
#pragma DATA_SECTION(FlashSerial, ".infoC")
uint8_t  FlashSerial[HOST_SERIAL_LENGTH];

#pragma DATA_SECTION(FlashCalPoints, ".infoC")
int16_t  FlashCalPoints[HOST_NUM_DEVICES*HOST_CALPTS_SIZE];

#pragma DATA_SECTION(FlashCalConst, ".infoC")
float  FlashCalConst[HOST_NUM_DEVICES*HOST_CALCONST_SIZE];

// calibration points
static int16_t calPoints[HOST_NUM_DEVICES*HOST_CALPTS_SIZE];
static float calConst[HOST_NUM_DEVICES*HOST_CALCONST_SIZE];
static uint8_t  serial[HOST_SERIAL_LENGTH];

#define TRANSFER_TABLE_SIZE_3RD         4
static const float g3rdOrderCoefTable[TRANSFER_TABLE_SIZE_3RD] = {
     205.5894,
     -0.1814103,
     -0.000003325395,
     -0.000000001809628
};

// this shared secret is randomly generated, do not change
// ^q,}pt#>(bv5#3#xs(r4yfo(a<s(cn
static const uint8_t sharedSecret[30] = {
		'^','q',',','}','p','t','#','>',
		'(','b','v','5','#','3','#','x',
		's','(','r','4','y','f','o','(',
		'a','<','s','(','c','n'
};


const uint8_t HOST_CONTROLLER_TYPE[] = {"Temperature Board\0"};


uint8_t bufferX[MAX_BUF_LENGTH];
uint8_t bufferY[MAX_BUF_LENGTH];

uint8_t *mbuf=bufferX;
uint8_t *ubuf;

volatile uint8_t LMT70_ADCReady = 0;
volatile uint16_t LMT70_ADC_Value;
uint16_t xy_buf_length = 2;

const uint8_t HOST_FIRMWARE_VERSION[] = {Firmware_VersionA,Firmware_VersionB,Firmware_VersionC,Firmware_VersionD};
const uint8_t HOST_CMD_STREAM_WHITELIST[] = {
		HOST_CMD_CONTROLLER_TYPE,
		HOST_CMD_FIRMWARE_VERSION,
		HOST_CMD_ENUMERATE_DEVICES,
		HOST_CMD_I2C_READ_BYTES,
		HOST_CMD_READ_ALL_DATA,
		HOST_CMD_SET_LED_STATES
};

// for USB
extern uint8_t bCDCDataReceived_event;

// for timing (scheduler)
extern volatile uint16_t timer_ticks;

// host device variables
static uint8_t host_devices[HOST_NUM_DEVICES + 1] = { HOST_NUM_DEVICES, HOST_DEVICE_CURRENT };
static uint8_t default_addr;
static uint8_t default_dev = 1;

uint16_t gCalREF_factor, gCalADC12_gain;
int16_t gCalADC12_offset;

// menu prototypes
static void menuReadLTM70();
static void menuReadHDC1080();
static void menuReadMCP9808();
static void menuReadSi7021();
//static void menuDecreasePeriod();
//static void menuIncreasePeriod();
//static void menuCycleLEDS();
//static void menuCycleI2CAddr();

static void applyCalibrationFactorsToADCReading(uint16_t rawValue, uint16_t *pValueAfterCal);
static void convertADCReadingToDegreeC(uint16_t calValue, float *pDegC);

// string menu variables
static host_menu_item_t menu_items[] = {
		{'2',"LMT70",&menuReadLTM70,NULL},
		{'3',"MCP9808", menuReadMCP9808, NULL},
		//{'4',"stop stream",&menuReadMCP9808,NULL},
		{'4',"Si7021",&menuReadSi7021,NULL},
//		{'5',"stream period-",&menuDecreasePeriod,NULL},
//		{'6',"stream period+",&menuIncreasePeriod,NULL},
//		{'7',"cycle LEDs",&menuCycleLEDS,NULL},
//		{'8',"cycle I2CAddr",&menuCycleI2CAddr,NULL}
};
#define HOST_INTERFACE_MENU_ITEMS (sizeof(menu_items)/sizeof(host_menu_item_t))

static enum {
		NORMAL = 0,
		ASCII
} packet_stream_type;

// streaming packet variables
//static uint8_t packet_stream_lock;
//static host_stream_start_data_t * packet_stream_data;

// tasks
static host_task_data_t packet_tasks[HOST_INTERFACE_MAX_STREAM_TASKS];

// prototypes
void taskStreamExecute(scheduled_task_t * self);
float MCP9808Conversation(uint8_t upperbyte, uint8_t lowerbyte);

static void taskStopAll() {
	uint8_t i;
	for (i = 0; i < HOST_INTERFACE_MAX_STREAM_TASKS; i++) {
		if (packet_tasks[i].task.active == TRUE) {
			removeTask(&packet_tasks[i].task);
		}
	}
}
static uint8_t getTaskIndexFromPID(uint8_t pid) {
	uint8_t i;
	for (i = 0; i < HOST_INTERFACE_MAX_STREAM_TASKS; i++) {
		if (packet_tasks[i].task.pid == pid) {
			return i;
		}
	}
	return i;
}
static uint8_t getTaskIndexIdle() {
	uint8_t i;
	for (i = 0; i < HOST_INTERFACE_MAX_STREAM_TASKS; i++) {
		if (packet_tasks[i].task.active == FALSE) {
			return i;
		}
	}
	return i;
}
// apply correction to raw data (from calibration params)
static uint16_t applyCalConst(uint16_t x, uint8_t dataOffset) {
	float data = (float) x;
	// apply linear formula to data
	// apply scaling factor
	if (calConst[dataOffset+ HOST_CALCONST_SCALE] != 1.0) {
		data *= calConst[dataOffset+ HOST_CALCONST_SCALE];
	}
	// apply offset
	if (calConst[dataOffset+ HOST_CALCONST_OFFSET] != 0) {
		data += calConst[dataOffset+ HOST_CALCONST_OFFSET];
	}
	// clamp
	if (data < 0) data = 0;
	if (data > 65535) data = 65535;
	// typedef x
	x = (uint16_t) data;
	return x;
}

static void saveAllFlash() {
    uint16_t status;

#if 0
    //5xx Workaround: Disable global interrupt while erasing.
    //local variable to store GIE status
    uint16_t gieStatus;

    disableSVS();

    //Store current SR register
    gieStatus = __get_SR_register() & GIE;
    //Disable global interrupt
    __disable_interrupt();

    //Erase INFOC
    do {
            //Erase INFOC
            FLASH_segmentErase(FLASH_BASE,
                               (uint8_t*)INFOC_START
                               );
            status = FLASH_eraseCheck(FLASH_BASE,
                                      (uint8_t*)INFOC_START,
                                      128
                                      );
    } while (status == 0);

	//Write calibration data to INFOC
	if (!(calcCRC8((uint8_t *) &serial[0], HOST_SERIAL_LENGTH))) {
//		for (x = 0; x < HOST_SERIAL_LENGTH; x++) {
//			serial[x] ^= sharedSecret[x];
//		}
	    FLASH_write8(FLASH_BASE,
	                 (uint8_t*)serial,
	                 (uint8_t*)FlashSerial,
	                 HOST_SERIAL_LENGTH
	                 );
	}
    FLASH_write8(FLASH_BASE,
                 (uint8_t*)calPoints,
                 (uint8_t*)FlashCalPoints,
                 sizeof(int16_t) * HOST_NUM_DEVICES*HOST_CALPTS_SIZE
                 );
    FLASH_write8(FLASH_BASE,
                 (uint8_t*)calConst,
                 (uint8_t*)FlashCalConst,
                 sizeof(float) * HOST_NUM_DEVICES*HOST_CALCONST_SIZE
                 );

    enableSVS();

    //Reinstate SR register
    __bis_SR_register(gieStatus);

#endif
}

static void menuReadLTM70() {
	uint16_t i;
	uint32_t data;
	uint16_t calValue;
	float degC;
	uint64_t timeout_ticks, starting_ticks, adc_ticks;

	uint8_t printString[40]={"Meas LMT70\n"};

	  starting_ticks = timer_ticks;
	  // Init T_ON signal: output and high
	  TI_LMT70_GPIO_T_ON_PxOUT |= TI_LMT70_GPIO_T_ON_PIN;
	  TI_LMT70_GPIO_T_ON_PxDIR |= TI_LMT70_GPIO_T_ON_PIN;

	  // read calibration values
	  // The reason of reading it every time is we may go to sleep and lost these value in RAM
	  // if we only read it once during initialization routine
	  read_adc12_calibration(&gCalREF_factor, &gCalADC12_gain, &gCalADC12_offset, VREF_15);

	  gAdc_Acccumlator = 0;
	  // init ADC12
	  adc12_init(CLK_DIVIDE);

	  // We are going to take NUM_ADC_SAMPLES then averages it out
	  for (i=0;i<NUM_ADC_SAMPLES;i++){
	      read_adc12_result(ADC12INCH_7);

	      timeout_ticks = timer_ticks + 2;
	    while (!LMT70_ADCReady && (timeout_ticks>=timer_ticks))

        LMT70_ADCReady = 0;
        applyCalibrationFactorsToADCReading(LMT70_ADC_Value, &calValue);

        gAdc_Acccumlator+=calValue;
            //TBD how to return the value in degC to the upper application layer??

	  }

	  // the same as dividing the sum by 256 to get the average value
	  gAdc_Acccumlator >>=NUM_ADC_SAMPLES_IN_BITS;

      convertADCReadingToDegreeC(calValue, &degC);

      adc_ticks = timer_ticks - starting_ticks;

      i=  sprintf ((char *)printString,"LMT70 Performance: %08x\n\r", adc_ticks);

      i = sprintf ((char *)printString,"LMT70 Avg Cal:%04x\n\r", gAdc_Acccumlator);
              bcUartSend((char *)printString, i);

      bcUartSend((char *)printString, i);
      sendString((char *)printString,i);
      i = sprintf ((char *)printString,"LMT70 Temp: %.4f\r\n\r\n", degC);
      bcUartSend((char *)printString, i);
      sendString((char *)printString,i);
}

/*
 * The algorithm is obtained from document http://www.ti.com/lit/ug/tidu802/tidu802.pdf
 * Title: LMT70 Thermal Response for Wearable Devices
 * Voltage Reference Calibration:
 * The LMT70EVM uses a 1.5V internal voltage reference for the integrated SAR ADC
 * ADC(ref_corrected) = ADC(raw) ∗ CAL_ADC_15VREF_FACTOR * 1/2^15
 *
 * Offset and Gain Correction:
 * The final ADC value with offset and gain can be corrected using the following steps:
 * ADC(gain_corrected) = ADC(ref_corrected) ∗ CAL_ADC_GAIN_FACTOR * 1/2^15
 *
 * ADC(ref_gain_offset_corrected) = ADC(gain_corrected) + CAL_ADC_OFFSET
 */
static void applyCalibrationFactorsToADCReading(uint16_t rawValue, uint16_t *pValueAfterCal)
{

    //although all the value are in 16 bit, we need to use 32 bit local variables to
    //deal with over-flow situation
    uint32_t adc_ref_correcated, adc_raw, adc_gain_correcated, adc_ref_offset_correcated;
    uint32_t temp;

    adc_raw = (uint32_t)rawValue;

    //ADC(ref_corrected) = ADC(raw) ∗ CAL_ADC_15VREF_FACTOR * 1/2^15
    temp = (uint32_t)(adc_raw * gCalREF_factor);
    adc_ref_correcated = temp >> 15;

    //ADC(gain_corrected) = ADC(ref_corrected) ∗ CAL_ADC_GAIN_FACTOR * 1/2^15

    temp = (uint32_t)(adc_ref_correcated * gCalADC12_gain);
    adc_gain_correcated =  temp >> 15;

    //ADC(ref_gain_offset_corrected) = ADC(gain_corrected) + CAL_ADC_OFFSET
    adc_ref_offset_correcated = (uint32_t)adc_gain_correcated + gCalADC12_offset;

    *pValueAfterCal = (uint16_t)adc_ref_offset_correcated;

}

/*
 * According to LMT70 data sheet, there are 3 transfer functions:
 * 1st order transfer function with Look Up Table (LUT)
 * 2nd order transfer function (with 2 sets of parameter depends of temperature range span
 * 3nd order transfer function (with 2 sets of parameter depends of temperature range span
 *
 * I will implement 3rd transfer function with coefficients that best fit for range -10 to 110
 *
 * The downside of 3rd tranfer function is that it will take up more memory and computation time
 *
 */
static void convertADCReadingToDegreeC(uint16_t calValue, float *pDegC)
{
    float vTAO, vTAO2, vTAO3;
    float const sizeof12Bit = 4096.0, vRef = 1500;  //reference voltage is 1.5V == 1500mV
    uint8_t printString[32];
    int i;

    //Convert calibrated ADC count to mV as value of VTAO
    vTAO = (float)calValue / sizeof12Bit * vRef;
    vTAO2 = vTAO * vTAO;
    vTAO3 = vTAO2 * vTAO;

    //i = sprintf ((char *)printString,"LMT70 Voltage : %f\r\n", vTAO);

    //bcUartSend((char *)printString, i);
    //Apply 3rd order transfer function
    //TM = k1(VTAO)^3 + k2(VTAO)^2 + k3(VTAO) + d
    *pDegC = g3rdOrderCoefTable[3]* vTAO3;                //break the calculation down for easier debugging
    *pDegC += g3rdOrderCoefTable[2]* vTAO2;
    *pDegC += g3rdOrderCoefTable[1]*vTAO;
    *pDegC += g3rdOrderCoefTable[0];

}

static void menuReadHDC1080() {
	uint8_t i;
	uint32_t data;
	uint8_t printString[32]={"Meas Humidity\n"};
	uint8_t testData[4]={20,21,22,23};


	// initiate conversion
	if (!i2c_writeByte(HDC1080_I2C_ADDRESS, HDC1080_CMD_HUMIDITY)) {
		i = sprintf ((char *)printString,"err pointer\r\n");
	}
	else {

		// timeout at 15ms
		data = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};

		// read data
		if (!i2c_readBytes(HDC1080_I2C_ADDRESS, &printString[0], 2)) {
			i = sprintf ((char *)printString,"err DRDY\r\n");
		}
		else {
			data = printString[1] | (printString[0] << 8);
			i = (default_dev-1)*HOST_CALCONST_SIZE+HOST_CALCONST_HUMIDITY;
			data = applyCalConst(data, i); // apply calibration params
			i = sprintf ((char *)printString,"%04x\r\n",data);
		}
	}

	sendString((char *)printString,i);
}
void menuReadAll(scheduled_task_t * self) {
	uint8_t i, j;
	uint32_t data;
	uint8_t printString[16];

	//Read Manufactuere ID for testing. expected return value is 0x54
	if (packet_stream_type == ASCII) {
		// initiate conversion
		if (!i2c_writeByte(MCP9808_I2C_ADDRESS, MCP9808_CMD_DEVID)) {
			i = sprintf ((char *)&printString[0],"err,");
		}
		else {

		// timeout at 15ms
		data = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};

			// read data
			if (!i2c_readBytes(HDC1080_I2C_ADDRESS, &printString[0], 2)) {
				i = sprintf ((char *)&printString[0],"err,");
			}
			else {
				data = printString[1] | (printString[0] << 8);
				j = (default_dev-1)*HOST_CALCONST_SIZE+HOST_CALCONST_TEMP;
				data = applyCalConst(data, j); // apply calibration params
				i = sprintf ((char *)&printString[0],"%04x,",data);
			}
		}
		// initiate conversion
		if (!i2c_writeByte(HDC1080_I2C_ADDRESS, HDC1080_CMD_HUMIDITY)) {
			i += sprintf ((char *)&printString[i],"err\r\n");
		}
		else {

		// timeout at 15ms
		data = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};

			// read data
			if (!i2c_readBytes(HDC1080_I2C_ADDRESS, &printString[i], 2)) {
				i += sprintf ((char *)&printString[i],"err\r\n");
			}
			else {
				data = printString[i+1] | (printString[i] << 8);
				j = (default_dev-1)*HOST_CALCONST_SIZE+HOST_CALCONST_HUMIDITY;
				data = applyCalConst(data, j); // apply calibration params
				i += sprintf ((char *)&printString[i],"%04x\r\n",data);
			}
		}
		sendString((char *)printString,i);
	}
}
static void menuReadMCP9808() {
	uint8_t x, i;
	uint32_t timeOutTicks;
	float temperature;
	char dataBuffer[4], printString[16];

	if (!i2c_writeByte(MCP9808_I2C_ADDRESS, MCP9808_CMD_TABIENT))
	{
		i = sprintf ((char *)printString,"err pointer\r\n");
	}
	else {

		// timeout at 15ms
		timeOutTicks = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};
		while (timer_ticks != timeOutTicks){};

		// read data
		if (!i2c_readBytes(MCP9808_I2C_ADDRESS, &dataBuffer[0], 2)) {
			i = sprintf ((char *)printString,"err DRDY\r\n");
		}
		else {
			//i = (default_dev-1)*HOST_CALCONST_SIZE+HOST_CALCONST_TEMP;
			//data = applyCalConst(data, i); // apply calibration params
			timeOutTicks = dataBuffer[0];
			timeOutTicks = timeOutTicks<<8 | dataBuffer[1];
			i = sprintf ((char *)printString,"Raw: %04x\r\n",timeOutTicks);
			sendString((char *)printString,i);

			temperature = MCP9808Conversation(dataBuffer[0], dataBuffer[1]);
			i = sprintf ((char *)printString,"%.4f\r\n",temperature);
		}
	}
	sendString((char *)printString,i);

}
static void menuReadSi7021() {
	uint8_t i,dataBuffer[4];
	uint16_t temp;
	uint32_t timeOutTicks;
	float temperature, humidity;

	char printString[32];

	//read temperature
	if (!i2c_writeByte(SI7021_I2C_ADDRESS, SI7021_CMD_MEA_TEMP_NO_HOLD))
		{
			i = sprintf ((char *)printString,"err pointer\r\n");

		}
		else {

			// timeout at 15ms
			timeOutTicks = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
			//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};
			while (timer_ticks != timeOutTicks){};

			// read data
			if (!i2c_readBytes(SI7021_I2C_ADDRESS, &dataBuffer[0], 3)) {
				i = sprintf ((char *)printString,"err DRDY\r\n");

			}
			else {

				temp = dataBuffer[0];
				temp = temp<<8 | dataBuffer[1];
				i = sprintf ((char *)printString,"Si7021 Raw: %04x\r\n",temp);
				//sendString((char *)printString,i);
				//bcUartSend((char *)printString, i);

				//Do the conversation to find out the temperature in degC
				temperature = (float)temp;
				temperature *= 175.72;
				temperature /= 65536.0;
				temperature -= 46.85;

				i = sprintf ((char *)printString,"Si7021 Temp: %.4f\r\n",temperature);
			}
		}
	    bcUartSend((char *)printString, i);
		sendString((char *)printString,i);

		//read humidity
		if (!i2c_writeByte(SI7021_I2C_ADDRESS, SI7021_CMD_MEA_HUM_NO_HOLD))
			{
				i = sprintf ((char *)printString,"err pointer\r\n");

			}
			else {

				// timeout at 15ms
				timeOutTicks = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
				//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};
				while (timer_ticks != timeOutTicks){};

				// read data
				if (!i2c_readBytes(SI7021_I2C_ADDRESS, &dataBuffer[0], 3)) {
					i = sprintf ((char *)printString,"err DRDY\r\n");

				}
				else {

					temp = dataBuffer[0];
					temp = temp<<8 | dataBuffer[1];
					i = sprintf ((char *)printString,"Si7021 Raw: %04x\r\n",temp);
					//sendString((char *)printString,i);

					//Do the conversation to find out the relative humidity in %
					humidity = (float)temp;
					humidity *= 125.0;
					humidity /= 65536.0;
					humidity -= 6;

					i = sprintf ((char *)printString,"Si7021 Hum: %.4f\r\n",humidity);
				}
			}
		bcUartSend((char *)printString, i);
		sendString((char *)printString,i);

}

#if 0
static void menuDecreasePeriod() {
	uint8_t x;
	char printString[16];
	x = getTaskIndexFromPID(HOST_PID_MENU_READ_ALL);
	// task does not exist
	if (x >= HOST_INTERFACE_MAX_STREAM_TASKS) {
		x = sprintf ((char *)printString,"no stream\r\n");
	}
	else {
		if (packet_tasks[x].task.ticks >= (HOST_STREAM_TICKS_MIN + HOST_STREAM_TICKS_INC)) {
			packet_tasks[x].task.ticks -= HOST_STREAM_TICKS_INC;
		}
		x = sprintf ((char *)printString,"%d ms\r\n",packet_tasks[x].task.ticks/100);
	}
	sendString((char *)printString,x);
}

static void menuCycleLEDS() {
	uint8_t x;
	char printString[8];
	//x = evm_LED_Set(CYCLE);
	x = sprintf ((char *)printString,"%02x\r\n",x);
	sendString((char *)printString,x);
}

static void menuIncreasePeriod() {
	uint8_t x;
	char printString[16];
	x = getTaskIndexFromPID(HOST_PID_MENU_READ_ALL);
	// task does not exist
	if (x >= HOST_INTERFACE_MAX_STREAM_TASKS) {
		x = sprintf ((char *)printString,"no stream\r\n");
	}
	else {
		if (packet_tasks[x].task.ticks <= (HOST_STREAM_TICKS_MAX - HOST_STREAM_TICKS_INC)) {
			packet_tasks[x].task.ticks += HOST_STREAM_TICKS_INC;
		}
		x = sprintf ((char *)printString,"%d ms\r\n",packet_tasks[x].task.ticks/100);
	}
	sendString((char *)printString,x);
}

static void menuCycleI2CAddr() {
	uint8_t x;
	char printString[8];
	if (++default_addr > EVM_MAX_I2CADDR) {
		default_addr = EVM_MIN_I2CADDR;
	}
	x = sprintf ((char *)printString,"%02x\r\n",default_addr);
	sendString((char *)printString,x);
}
#endif

static void readCalFromFlash() {
	uint8_t i, j, k, l, m;
	uint16_t * n;
	for (i = 0; i < HOST_NUM_DEVICES*HOST_CALPTS_SIZE; i++) {
		calPoints[i] = FlashCalPoints[i];
		if (calPoints[i] == 0xFFFF) {
			calPoints[i] = 0;
		}
	}
	for (j = 0; j < HOST_NUM_DEVICES; j++) {
		for (i = 0; i < HOST_CALCONST_SET_NUM; i++) {
			for (k = 0; k < HOST_CALCONST_SET_SIZE; k++) {
				l = j*HOST_CALCONST_SIZE+i*HOST_CALCONST_SET_NUM+k;
				calConst[l] = FlashCalConst[l];
				n = (uint16_t *)&calConst[l];
				for (m = 0; m < (sizeof(float)/sizeof(uint16_t)); m++) {
					if ((*n) != 0xFFFF) {
						break;
					}
					n++;
				}
				if (m == (sizeof(float)/sizeof(uint16_t))) {
					if (k == HOST_CALCONST_OFFSET) {
						calConst[l] = 0;
					}
					else if (k == HOST_CALCONST_SCALE) {
						calConst[l] = 1.0;
					}
				}
			}
		}
	}
}
static void readSerialFromFlash() {
//	uint8_t i;
	// decode serial
//	for (i = 0; i < HOST_SERIAL_LENGTH; i++) {
//		serial[i] = FlashSerial[i] ^ sharedSecret[i];
//	}
	memcpy(&serial[0],&FlashSerial[0],HOST_SERIAL_LENGTH);
	// validate crc
	if (calcCRC8((uint8_t *) &serial[0], HOST_SERIAL_LENGTH)) {
		memset(&serial[0],0xFF,HOST_SERIAL_LENGTH);
	}
}

void initHostInterface() {
	uint8_t i;
//	default_dev = 1;
	//default_addr = EVM_DEFAULT_I2CADDR;

	// TODO: scan for attached devices, add commands based on devices found
	packet_stream_type = NORMAL;
	initMenuItems();
	for (i = 0; i < HOST_INTERFACE_MENU_ITEMS; i++) {
		addMenuItem(&menu_items[i]);
	}
	// reset packet_tasks
	for (i = 0; i < HOST_INTERFACE_MAX_STREAM_TASKS; i++) {
		packet_tasks[i].task.timedout = FALSE;
		packet_tasks[i].task.active = FALSE;
	}
	initScheduler();

	TP1_LEDDIR |= TP1_LEDBIT;
	TP2_LEDDIR |= TP2_LEDBIT;
}

static void sendPacket (host_cmd_packet_t *packet, uint8_t size) {
//	static WORD i;
	packet->fields.crc = calcCRC8((uint8_t *)packet, size-HOST_CRC_SIZE);
	packet->bytes[size-HOST_CRC_SIZE] = packet->fields.crc;
//    if (cdcSendDataInBackground((BYTE*)packet,(WORD)size,CDC0_INTFNUM,0))
    if (cdcSendDataInBackground((BYTE*)packet,(WORD)HOST_MAX_REPLY_PACKET_LENGTH,CDC0_INTFNUM,0))
    {      //Send it
//        USBCDC_abortSend((WORD*)&i,CDC0_INTFNUM);              //Operation probably still open; cancel it
    	_nop();
    }
}
static void sendErrorPacket (host_cmd_packet_t *packet, ERROR_CODE error_code) {
	packet->fields.hdr.length = 0;
	packet->fields.hdr.err_code = (int8_t) error_code;
	sendPacket(packet,HOST_ERR_PACKET_LENGTH);
}

static void executeCmdPacket (host_cmd_packet_t * responsePkt) {
	static uint16_t x;
	// Load the Reply Packet Header
//    	responsePkt->fields.hdr.id = HOST_ID;
//    	responsePkt->fields.hdr.command_code = commandPkt->fields.hdr.command_code;
//    	responsePkt->fields.hdr.device_num = commandPkt->fields.hdr.device_num;
//    	responsePkt->fields.hdr.err_code = (uint8_t)ERR_OK;

	switch (responsePkt->fields.hdr.command_code)
	{
		case HOST_CMD_CONTROLLER_TYPE:
			// copy from const data
			memcpy(&(responsePkt->fields.data[0]),&HOST_CONTROLLER_TYPE[0],HOST_CONTROLLER_TYPE_LENGTH);
			responsePkt->fields.hdr.length = HOST_CONTROLLER_TYPE_LENGTH;
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + HOST_CONTROLLER_TYPE_LENGTH + HOST_CRC_SIZE);
			break;
		case HOST_CMD_FIRMWARE_VERSION:
			// copy from const data
			memcpy(&(responsePkt->fields.data[0]),&HOST_FIRMWARE_VERSION[0],HOST_FIRMWARE_VERSION_LENGTH);
			responsePkt->fields.hdr.length = HOST_FIRMWARE_VERSION_LENGTH;
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + HOST_FIRMWARE_VERSION_LENGTH + HOST_CRC_SIZE);
			break;
		case HOST_CMD_ENUMERATE_DEVICES:
			// copy from const data
			memcpy(&(responsePkt->fields.data[0]),&host_devices[0],host_devices[0] + 1);
			responsePkt->fields.hdr.length = host_devices[0] + 1;
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + host_devices[0] + 1 + HOST_CRC_SIZE);
			break;
		/*case HOST_CMD_SET_DEFAULT_DEVICE:*/
			// Set the default device
			// only one device so command not available
			/*break;*/
		case HOST_CMD_I2C_SETUP:
			// validate length and pec
			if (responsePkt->fields.hdr.length != 4) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			else if (responsePkt->fields.data[3] != 0) {
				sendErrorPacket(responsePkt,ERR_PARAM_OUT_OF_RANGE);
				break;
			}
			x = (responsePkt->fields.data[2] << 8) | responsePkt->fields.data[1];
			// set the clock (kills any previous read/write)
			i2c_setClock((i2c_clock_t) (responsePkt->fields.data[0] & I2C_CLK_MASK), x);
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			break;
		case HOST_CMD_SMBUS_READ_BYTES:
			// validate length
			if (responsePkt->fields.hdr.length != 3) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			x = responsePkt->fields.data[2];
			// read bytes
			if (!smbus_readBytes(responsePkt->fields.data[0], &(responsePkt->fields.data[1]), x)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}
			else {
				responsePkt->fields.hdr.length = x + 2;
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			}
			break;
		case HOST_CMD_SMBUS_WRITE_BYTES:
			// validate length
			if (responsePkt->fields.hdr.length < 2) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			x = responsePkt->fields.hdr.length - 1;
			// write bytes
			if (!i2c_writeBytes(responsePkt->fields.data[0], &(responsePkt->fields.data[1]), x)) {
				sendErrorPacket(responsePkt,ERR_I2C_WRITE_TIMEOUT);
				break;
			}
			else {
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			}
			break;
		case HOST_CMD_I2C_READ_BYTES:
			// validate length
			if (responsePkt->fields.hdr.length != 2) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			x = responsePkt->fields.data[1];
			// read bytes
			if (!i2c_readBytes(responsePkt->fields.data[0], &(responsePkt->fields.data[1]), x)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}
			else {
				responsePkt->fields.hdr.length = x + 1;
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			}
			break;
		case HOST_CMD_I2C_WRITE_BYTES:
			// validate length
			if (responsePkt->fields.hdr.length == 0) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			x = responsePkt->fields.hdr.length - 1;
			// write bytes
			if (!i2c_writeBytes(responsePkt->fields.data[0], &(responsePkt->fields.data[1]), x)) {
				sendErrorPacket(responsePkt,ERR_I2C_WRITE_TIMEOUT);
				break;
			}
			else {
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			}
			break;
		case HOST_CMD_START_STREAM: {
			host_stream_start_packet_t * startPkt = (host_stream_start_packet_t *) responsePkt;
			// validate if command code is supported
			for (x = 0; x < sizeof(HOST_CMD_STREAM_WHITELIST); x++) {
				if (startPkt->fields.data.command_code == HOST_CMD_STREAM_WHITELIST[x]) {
					break;
				}
			}
			if (x >= sizeof(HOST_CMD_STREAM_WHITELIST)) {
				// command code not supported for streaming
				sendErrorPacket(responsePkt,ERR_PARAM_OUT_OF_RANGE);
				break;
			}
			x = getTaskIndexFromPID(startPkt->fields.data.pid);
			if (x >= HOST_INTERFACE_MAX_STREAM_TASKS) {
				// task not found; get idle index
				x = getTaskIndexIdle();
				// no tasks are idle; maximum tasks alloted
				if (x >= HOST_INTERFACE_MAX_STREAM_TASKS) {
					sendErrorPacket(responsePkt,ERR_PARAM_OUT_OF_RANGE);
					break;
				}
			}
			else {
				// remove existing task
				removeTask(&packet_tasks[x].task);
			}
			packet_stream_type = NORMAL;
			// setup packet
			memcpy(&packet_tasks[x].packet,startPkt,HOST_STREAM_IN_PACKET_LENGTH);
			packet_tasks[x].packet.fields.hdr.command_code = startPkt->fields.data.command_code;
			packet_tasks[x].packet.fields.hdr.length -= HOST_STREAM_IN_EHDR_LEN;
			// setup data
			if (packet_tasks[x].packet.fields.hdr.length) {
				memcpy(&packet_tasks[x].packet.fields.data,&startPkt->fields.data.bytes[0],packet_tasks[x].packet.fields.hdr.length);
			}
			// setup task
			// set PID
			packet_tasks[x].task.pid = startPkt->fields.data.pid;
			// set ticks
			packet_tasks[x].task.ticks = (startPkt->fields.data.interval_divider_hi << 8) |
					startPkt->fields.data.interval_divider_lo;
			// set task function
			packet_tasks[x].task.function = &taskStreamExecute;
			// start task
			addTask(&packet_tasks[x].task);
			}
		    sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			break;
		case HOST_CMD_STOP_STREAM:
			// validate length
			if (responsePkt->fields.hdr.length != 1) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			x = getTaskIndexFromPID(responsePkt->fields.data[0]);
			if (x >= HOST_INTERFACE_MAX_STREAM_TASKS) {
				sendErrorPacket(responsePkt,ERR_PARAM_OUT_OF_RANGE);
				break;
			}
			else {
				removeTask(&packet_tasks[x].task);
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			}
			break;
		case HOST_CMD_STOP_ALL_STREAMS:
			taskStopAll();
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			break;
		case HOST_CMD_READ_SERIAL:
			memcpy(&(responsePkt->fields.data[0]),&serial[0],HOST_SERIAL_LENGTH);
			responsePkt->fields.hdr.length = HOST_SERIAL_LENGTH;
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + HOST_SERIAL_LENGTH + HOST_CRC_SIZE);
			break;
		case HOST_CMD_WRITE_SERIAL:
			if (responsePkt->fields.hdr.length != HOST_SERIAL_LENGTH) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			// validate crc
			for (x = 0; x < HOST_SERIAL_LENGTH; x++) {
				serial[x] = responsePkt->fields.data[x] ^ sharedSecret[x];
			}
			if (calcCRC8((uint8_t *) &serial[0], HOST_SERIAL_LENGTH)) {
				// restore serial
				_disable_interrupts();
				readSerialFromFlash();
				_enable_interrupts();
				sendErrorPacket(responsePkt,ERR_PARAM_OUT_OF_RANGE);
				break;
			}
			saveAllFlash();
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + HOST_SERIAL_LENGTH + HOST_CRC_SIZE);
			break;
		case HOST_CMD_ENTER_BSL:
			taskStopAll();
			USB_reset ();
			USB_disable();
			_disable_interrupts();
			((void (*)())0x1000)();
			break;
		// HDC1000-specific cases
		case HOST_CMD_READ_ALL_DATA: {
			uint32_t data;
			uint8_t k;
			// validate length
			if (responsePkt->fields.hdr.length != 1) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			k = (responsePkt->fields.hdr.device_num-1) * HOST_CALCONST_SIZE + HOST_CALCONST_TEMP;
			// initiate conversion
			if (!i2c_writeByte(responsePkt->fields.data[0], HDC1080_CMD_TEMP)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}

		// timeout at 15ms
		data = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};

			// read data
			if (!i2c_readBytes(responsePkt->fields.data[0], &(responsePkt->fields.data[1]), 2)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}
			x = (responsePkt->fields.data[1] << 8) | responsePkt->fields.data[2];
			x = applyCalConst(x, k); // apply calibration params
			responsePkt->fields.data[1] = (x >> 8) & 0xFF;
			responsePkt->fields.data[2] = x & 0xFF;
			k = (responsePkt->fields.hdr.device_num-1) * HOST_CALCONST_SIZE + HOST_CALCONST_HUMIDITY;
			// initiate conversion
			if (!i2c_writeByte(responsePkt->fields.data[0], HDC1080_CMD_HUMIDITY)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}
		// timeout at 15ms
		data = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};


			// read data
			if (!i2c_readBytes(responsePkt->fields.data[0], &(responsePkt->fields.data[3]), 2)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}
			x = (responsePkt->fields.data[3] << 8) | responsePkt->fields.data[4];
			x = applyCalConst(x, k); // apply calibration params
			responsePkt->fields.data[3] = (x >> 8) & 0xFF;
			responsePkt->fields.data[4] = x & 0xFF;
			responsePkt->fields.hdr.length = 5;
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			break;
		}
		case HOST_CMD_SET_LED_STATES:
			// read
#if 0
			if (responsePkt->fields.hdr.length == 0) {
				responsePkt->fields.data[0] = evm_LED_State();
				responsePkt->fields.hdr.length = 1;
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
				break;
			}
			// validate length
			else if (responsePkt->fields.hdr.length != 1) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			//evm_LED_Set ((evm_led_state_t) (responsePkt->fields.data[0]));
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
#endif
			break;
		case HOST_CMD_DRDY_READ: {
			uint32_t data;
			uint8_t k;
			// validate length
			if (responsePkt->fields.hdr.length != 3) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			x = responsePkt->fields.data[1];
			// validate command code; we need this due to offsets
			if (x == HDC1080_CMD_TEMP) {
				k = (responsePkt->fields.hdr.device_num-1) * HOST_CALCONST_SIZE + HOST_CALCONST_TEMP;
			}
			else if (x == HDC1080_CMD_HUMIDITY) {
				k = (responsePkt->fields.hdr.device_num-1) * HOST_CALCONST_SIZE + HOST_CALCONST_HUMIDITY;
			}
			else {
				sendErrorPacket(responsePkt,ERR_PARAM_OUT_OF_RANGE);
				break;
			}
			// initiate conversion
			if (!i2c_writeByte(responsePkt->fields.data[0], x)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}

		// timeout at 15ms
		data = timer_ticks + HOST_DRDY_TIMEOUT_TICKS;
		//while ((timer_ticks != data) && EVM_DRDYN_HI()) {};


			// read length
			x = responsePkt->fields.data[2];
			// read data
			if (!i2c_readBytes(responsePkt->fields.data[0], &(responsePkt->fields.data[2]), x)) {
				sendErrorPacket(responsePkt,ERR_I2C_READ_TIMEOUT);
				break;
			}
			responsePkt->fields.hdr.length = x + 2;
			x = (responsePkt->fields.data[2] << 8) | responsePkt->fields.data[3];
			x = applyCalConst(x, k); // apply calibration params
			responsePkt->fields.data[2] = (x >> 8) & 0xFF;
			responsePkt->fields.data[3] = x & 0xFF;
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			break;
		}
		case HOST_CMD_CALIBRATION: {
			uint8_t j, k;
			int16_t ptA, ptB;
			j = (responsePkt->fields.hdr.device_num-1) * HOST_CALPTS_SIZE;
			k = (responsePkt->fields.hdr.device_num-1) * HOST_CALCONST_SIZE;
			// read
			if (responsePkt->fields.hdr.length == 0) {
				ptA = calPoints[j + HOST_CALPTS_TEMP];
				responsePkt->fields.data[0] = (ptA >> 8) & 0xFF;
				responsePkt->fields.data[1] = (ptA & 0xFF);
				ptA = calPoints[j + HOST_CALPTS_TEMP + 1];
				responsePkt->fields.data[2] = (ptA >> 8) & 0xFF;
				responsePkt->fields.data[3] = (ptA & 0xFF);
				ptA = calPoints[j + HOST_CALPTS_HUMIDITY];
				responsePkt->fields.data[4] = (ptA >> 8) & 0xFF;
				responsePkt->fields.data[5] = (ptA & 0xFF);
				ptA = calPoints[j + HOST_CALPTS_HUMIDITY + 1];
				responsePkt->fields.data[6] = (ptA >> 8) & 0xFF;
				responsePkt->fields.data[7] = (ptA & 0xFF);
				responsePkt->fields.hdr.length = 8;
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
				break;
			}
			// validate length
			else if (responsePkt->fields.hdr.length != 8) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			// save to calibration points temperature
			ptA = ((responsePkt->fields.data[0] << 8) | responsePkt->fields.data[1]);
			calPoints[j + HOST_CALPTS_TEMP] = ptA;
			ptB = ((responsePkt->fields.data[2] << 8) | responsePkt->fields.data[3]);
			calPoints[j + HOST_CALPTS_TEMP+1] = ptB;
			// save to correction offset and correction scaling factor
			calConst[k + HOST_CALCONST_TEMP + HOST_CALCONST_OFFSET] = (float)ptA;
			if (ptA != ptB) {
				calConst[k + HOST_CALCONST_TEMP + HOST_CALCONST_SCALE] = ((float)ptB)/((float)0x3FFF);
			}
			// save to calibration points humidity
			ptA = ((responsePkt->fields.data[4] << 8) | responsePkt->fields.data[5]);
			calPoints[j + HOST_CALPTS_HUMIDITY] = ptA;
			ptB = ((responsePkt->fields.data[6] << 8) | responsePkt->fields.data[7]);
			calPoints[j + HOST_CALPTS_HUMIDITY+1] = ptB;
			// save to correction offset and correction scaling factor
			calConst[k + HOST_CALCONST_HUMIDITY + HOST_CALCONST_OFFSET] = (float)ptA;
			if (ptA != ptB) {
				calConst[k + HOST_CALCONST_HUMIDITY + HOST_CALCONST_SCALE] = ((float)ptB)/((float)0x3FFF);
			}
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			break;
		}
		case HOST_CMD_SET_CONFIG_DEFAULT:
#if 0
			// read
			if (responsePkt->fields.hdr.length == 0) {
				x = evm_read_config_defaults();
				responsePkt->fields.data[0] = (x >> 8) & 0xFF;
				responsePkt->fields.data[1] = (x & 0xFF);
				responsePkt->fields.hdr.length = 2;
				sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
				break;
			}
#endif
			break;
			// validate length
			if (responsePkt->fields.hdr.length != 2) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			// Big Endian
			x = (responsePkt->fields.data[0] << 8) | responsePkt->fields.data[1];
			evm_set_config_default(x);
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
			break;
		case HOST_CMD_SAVE_SETTINGS:
#if 0
			// validate length
			if (responsePkt->fields.hdr.length != 0) {
				sendErrorPacket(responsePkt,ERR_BAD_PACKET_SIZE);
				break;
			}
			evm_save_defaults();
			saveAllFlash();
			sendPacket(responsePkt,HOST_OUT_HDR_SIZE + responsePkt->fields.hdr.length + HOST_CRC_SIZE);
#endif
			break;
		default:
			sendErrorPacket(responsePkt,ERR_INVALID_FUNCTION_CODE);
			break;
	}   // end switch

}

void processCmdPacket ()
{
static host_cmd_packet_t       commandPkt;
static host_cmd_packet_t       responsePkt;
static uint16_t x;

	// Set up rcv operation for 1 byte of data to make sure it is a header
	// If USBCDC_receiveData fails because of surprise removal
	// or suspended by host abort and leave main loop
	if (USBCDC_receiveData((BYTE*)&commandPkt.fields.hdr.id, 1, CDC0_INTFNUM) ==
		kUSBCDC_busNotAvailable)
	{
		x = 1;
		USBCDC_abortReceive(&x,CDC0_INTFNUM);
		return;
	}

    // check namespace, if not the same, trigger ASCII menu
    if (commandPkt.fields.hdr.id != HOST_ID) {
    	if (!executeMenuItem(commandPkt.fields.hdr.id)) {
    		x = USBCDC_rejectData(CDC0_INTFNUM);
    		// consume excess bytes in buffer
    	}
    	return;
    }

    // Set up rcv operation for rest of header data
    // If USBCDC_receiveData fails because of surprise removal
    // or suspended by host abort and leave main loop
    if (USBCDC_receiveData((BYTE*)&commandPkt.fields.hdr.command_code ,HOST_IN_HDR_SIZE-1, CDC0_INTFNUM) ==
        kUSBCDC_busNotAvailable)
    {
        x = HOST_IN_HDR_SIZE - 1;
        USBCDC_abortReceive(&x,CDC0_INTFNUM);
        return;
    }

    // validate header
    // Validate packet length
     if (commandPkt.fields.hdr.length > HOST_MAX_CMD_DATA_LEN) {
         memcpy((uint8_t *)&responsePkt,(uint8_t *)&commandPkt, HOST_IN_HDR_SIZE);
         sendErrorPacket(&responsePkt,ERR_BAD_PACKET_SIZE);
         return;
     }
     // check device number out of range
     else if (commandPkt.fields.hdr.device_num > 1) {
         memcpy((uint8_t *)&responsePkt,(uint8_t *)&commandPkt, HOST_IN_HDR_SIZE);
         sendErrorPacket(&responsePkt,ERR_INVALID_DEVICE);
         return;
     }
     // check for host-side crc errors
     else if (commandPkt.fields.hdr.err_code != (int8_t)ERR_OK) {
         memcpy((uint8_t *)&responsePkt,(uint8_t *)&commandPkt, HOST_IN_HDR_SIZE);
         sendErrorPacket(&responsePkt,ERR_PARAM_OUT_OF_RANGE);
         return;
     }

    // Receive the rest of the data
    if (USBCDC_receiveData((BYTE*)&commandPkt.fields.data[0],commandPkt.fields.hdr.length + HOST_CRC_SIZE, CDC0_INTFNUM) ==
        kUSBCDC_busNotAvailable)
    {
        x = commandPkt.fields.hdr.length+HOST_CRC_SIZE;
        USBCDC_abortReceive(&x,CDC0_INTFNUM);
        return;
    }

    x = HOST_IN_HDR_SIZE + commandPkt.fields.hdr.length + HOST_CRC_SIZE;

	// Valid packet will compute to a CRC of 0, when the CRC of the entire packet, including the CRC Bye is computed
	if (calcCRC8((uint8_t *) &commandPkt, (uint8_t) x))
	{
		memcpy((uint8_t *)&responsePkt,(uint8_t *)&commandPkt, HOST_IN_HDR_SIZE);
		sendErrorPacket(&responsePkt,ERR_COM_CRC_FAILED);
        return;
	}
	// execute command
	else
	{
		memcpy((uint8_t *)&responsePkt,(uint8_t *)&commandPkt, x);
		executeCmdPacket(&responsePkt);
		return;
	}
}

void taskStreamExecute(scheduled_task_t * self) {
	static uint8_t x, y;
	static host_cmd_packet_t responsePkt;
	if (packet_stream_type == NORMAL) {
		x = getTaskIndexFromPID(self->pid);
		if (x < HOST_INTERFACE_MAX_STREAM_TASKS) {
			y = HOST_IN_HDR_SIZE + packet_tasks[x].packet.fields.hdr.length + HOST_CRC_SIZE;
			memcpy((uint8_t *)&responsePkt,(uint8_t *)&packet_tasks[x].packet, y);
			executeCmdPacket(&responsePkt);
		}
	}
}


/** LEDS and Test Points TP */
static uint8_t led_status = 0;
static uint8_t tp_status = 0;
uint8_t evm_LED_Set(evm_led_state_t state) {
	switch (state) {
	case ALLTOGGLE:
		led_status ^= 0x03;
		break;
	case CYCLE:
		led_status += 1;
		led_status &= 0x03;
		break;
	case GREEN:
		led_status = 0x01;
		break;
	case RED:
		led_status = 0x02;
		break;
	case ALLON:
		led_status = 0x03;
		break;
	case ALLOFF:
		led_status = 0x00;
		break;
	case TP3ON:
	    tp_status = 0x1;
	    break;
	case TP3OFF:
	    tp_status &= 0xFE;
	    break;
	case TP3TOGGLE:
	    tp_status ^= 0x01;
	    break;
    case TP4ON:
        tp_status = 0x2;
        break;
    case TP4OFF:
        tp_status &= 0xFD;
        break;
    case TP4TOGGLE:
        tp_status ^= 0x02;
        break;

	default:
		break;
	}
	if (led_status & 0x01) {
		TP1_LED_ON();
	}
	else {
		TP1_LED_OFF();
	}
	if (led_status & 0x02) {
		TP2_LED_ON();
	}
	else {
		TP2_LED_OFF();
	}

    if (tp_status & 0x01) {
        TP3_ON();
    }
    else {
        TP3_OFF();
    }
    if (tp_status & 0x02) {
        TP4_ON();
    }
    else {
        TP4_OFF();
    }

	return led_status;
}

uint8_t evm_LED_State() {
	return led_status;
}

float MCP9808Conversation(uint8_t upperbyte, uint8_t lowerbyte)
{
	float temperature;
	uint8_t local_upperbyte;

	local_upperbyte = upperbyte & 0x1F;			// clear the upper 3 bits, which are the flag bits

	// check for the sign bit
	if ((local_upperbyte & 0x10)==0x10)
	{
		local_upperbyte = local_upperbyte & 0x0F;    //clear the SIGN bit
		temperature = 256.0 - ((float)local_upperbyte * 16.0 + (float)lowerbyte/16.0);
	}
	else
	{
		temperature = (float)local_upperbyte * 16.0 + (float)lowerbyte/16.0;
	}

	return temperature;
}
