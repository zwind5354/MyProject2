/* Copyright (C) 2015 Texas Instruments Incorporated - http://www.ti.com/  ALL RIGHTS RESERVED  */

#include "host_packet.h"
#include "driverlib/scheduler.h"

#ifndef HOST_INTERFACE_H_
#define HOST_INTERFACE_H_

#define Firmware_VersionA 0
#define Firmware_VersionB 0
#define Firmware_VersionC 1
#define Firmware_VersionD 0

#define HOST_CMD_READ_ALL_DATA      0x30
#define HOST_CMD_CALIBRATION    	0x31
#define HOST_CMD_SET_LED_STATES     0x32
#define HOST_CMD_DRDY_READ          0x33
#define HOST_CMD_SET_CONFIG_DEFAULT 0x34
#define HOST_CMD_SAVE_SETTINGS      0x3A

#define HOST_DEVICE_HDC1000 0x10


#ifdef HOST_DEVICE_HDC1000
#define  HOST_DEVICE_CURRENT HOST_DEVICE_HDC1000
#endif

#define EVM_MIN_I2CADDR     0x40
#define EVM_MAX_I2CADDR     0x43
#define EVM_DEFAULT_I2CADDR EVM_MIN_I2CADDR


typedef enum {
	ALLTOGGLE = 0,
	GREEN = 1,
	RED = 2,
	ALLON = 3,
	ALLOFF = 4,
	CYCLE = 5,
	TP3ON = 6,
	TP3OFF = 7,
	TP3TOGGLE =8,
	TP4ON = 9,
	TP4OFF = 10,
	TP4TOGGLE= 11
} evm_led_state_t;

typedef struct
{
	host_cmd_packet_t packet;
	scheduled_task_t task;
} host_task_data_t;

// data lengths must not exceed HOST_MAX_CMD_DATA_LEN
#define HOST_FIRMWARE_VERSION_LENGTH     4
#define HOST_CONTROLLER_TYPE_LENGTH      10

#define HOST_STATUS_HDC_DRDY_TIMEOUT 0x01

#define HOST_PID_MENU_READ_ALL 0xFF

#define HOST_NUM_DEVICES 1

void initHostInterface();

void processCmdPacket ();

#endif
