/* Copyright (C) 2015 Texas Instruments Incorporated - http://www.ti.com/  ALL RIGHTS RESERVED  */

#ifndef HOST_MENU_H_
#define HOST_MENU_H_

#define HOST_MENU_MS 24000	   // ticks for 1ms

typedef struct host_menu_item {
	uint8_t id;
	char * name;
	void (* action)();
	struct host_menu_item * next;
} host_menu_item_t;

extern const uint8_t HOST_CONTROLLER_TYPE[];
extern const uint8_t HOST_FIRMWARE_VERSION[];
extern const uint8_t HOST_CMD_STREAM_WHITELIST[];

void sendString(char * string, uint8_t size);
void sendStringBackground(char * string, uint8_t size);
void initMenuItems();
uint8_t executeMenuItem(uint8_t id);
void addMenuItem(host_menu_item_t * item);

#endif /* HOST_MENU_H_ */
